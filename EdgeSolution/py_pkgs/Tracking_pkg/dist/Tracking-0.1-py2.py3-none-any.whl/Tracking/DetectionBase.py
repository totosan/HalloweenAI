class DetectionBase(object):
    def __init__(self, *args):
        pass
    
    def detect_single(self, frame):
        return frame
    
    def detect_multi(self, frame):
        return frame
